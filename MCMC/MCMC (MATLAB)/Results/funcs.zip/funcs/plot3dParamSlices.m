function plot3dParamSlices()

end
