function plotLogLikelihoodRatios()

end
