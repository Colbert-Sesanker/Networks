function NewOldOldNewRatios()

end
