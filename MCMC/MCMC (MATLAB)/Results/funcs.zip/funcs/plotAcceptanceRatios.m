function plotAcceptanceRatios()

end
